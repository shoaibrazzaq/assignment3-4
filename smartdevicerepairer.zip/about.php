
<html>
<body bgcolor="black">

 <p style="color:white">This website is made to save your precious time as if you got your laptop or mopbile damaged or broken then this website
 is for you, if you have not enough to go to shop and to repair you revice than by using this app you can get your smart device
 repaired by sitting at home. You only need to open our website and fill the form, Nothing else.WE give our customers best
 quality of repairng including all types of hardware repairing .We have both types of parts(low quality and high quality) which
 is based on customers needs. Our motive is to pick and deliver the product in committed time. We always make sure that our
 customers privacy,data and device will be secured.Our repairing center have best repairers in the market. Our repairing charges 
 will be less than market rate. The part of device which you will get from us will have warranty of one month. If customer don't
 know the fault in his device than we will check his device and notify him about the fault and expenses.If he wants to repair it
 from us  than we will repair it otherwise we will return it back to him with only delivery charges.We assure you that we will not
 let you down(THANK YOU).</p>

</body>
</html>
