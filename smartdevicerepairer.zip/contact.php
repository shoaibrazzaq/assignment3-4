 <html>
 <body style="color:red">

 <form name="f1">
     NAME:<input type="text" value="REHMAT ALI"readonly>
	      <br>
     PHONE NUMBER:<input type="text" value="03477111268"readonly>
	      <br>
     EMAIL:<input type="text" value="rehmat.ali@ucp.edu.pk" readonly>
	      <br>
		  <br>
		  <br>
	 NAME:<input type="text" value="SHOAIB RAZZAQ"readonly>
     <br>
     
	 PHONE NUMBER:<input type="text" value="03470460835"readonly>
     <br>
    
	 EMAIL:<input type="text" value="shoaib_razzaq@ucp.edu.pk" readonly>
     <br>
 </form>
 </body>
 </html>
