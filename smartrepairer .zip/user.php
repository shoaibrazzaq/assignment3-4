<?php
$nam= $_POST['stdname'];
$pass=$_POST['passw'];
echo $nam;
echo"<br>";
echo $pass;

?>